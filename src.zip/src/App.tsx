import React from 'react';
import { BrowserRouter, Routes, Route, Navigate, Link } from 'react-router-dom';
import { DinnerListPage } from './features/dinner/DinnerListPage';
import { DinnerDetailPage } from './features/dinner/DinnerDetailPage';
import { LoginPage } from './features/auth/LoginPage';
import { RegisterPage } from './features/auth/RegisterPage'; // 회원가입 페이지 추가
import { CartPage } from './features/cart/CartPage'; // 경로 주의!
import { AIChatDrawer } from './components/AIChatDrawer'; // AI 사이드바 컴포넌트
import { useUIStore } from './stores/useUIStore'; // UI 상태 관리


const App: React.FC = () => {
  // Zustand 스토어에서 AI창 토글 함수 가져오기
  const { toggleAIChat } = useUIStore();

  return (
    <BrowserRouter>
      <div className="min-h-screen bg-gray-50 relative">
        
        {/* 1. 상단 네비게이션 바 (Sticky Header) */}
        <nav className="bg-white shadow-sm border-b border-gray-200 px-4 py-3 flex justify-between items-center sticky top-0 z-30">
          {/* 로고 (클릭 시 홈으로) */}
          <Link to="/" className="text-xl font-extrabold text-green-700 flex items-center gap-2">
            <span>🍽️</span> Mr. DAEBAK
          </Link>

          {/* 우측 버튼 영역 */}
          <div className="flex items-center gap-3">
            {/* 로그인 버튼 (임시: 실제로는 로그인 여부에 따라 다르게 보여야 함) */}
            <Link 
              to="/login"
              className="text-sm font-medium text-gray-600 hover:text-green-600 hidden sm:block"
            >
              로그인
            </Link>

            {/* 장바구니 버튼 */}
            <Link 
              to="/cart"
              className="text-sm font-medium text-gray-600 hover:text-green-600 hidden sm:block"
            >
              장바구니
            </Link>

            {/* ★ AI 주문하기 버튼 (핵심) */}
            <button
              onClick={toggleAIChat}
              className="flex items-center gap-2 bg-green-100 text-green-800 px-4 py-2 rounded-full font-bold hover:bg-green-200 transition-colors shadow-sm"
            >
              <span>🤖</span>
              <span className="hidden xs:inline">AI 주문</span>
            </button>
          </div>
        </nav>

        {/* 2. 메인 컨텐츠 영역 */}
        {/* 상단 헤더에 가려지지 않게 pt 등을 조정할 필요가 있을 수 있음 (현재는 괜찮음) */}
        <Routes>
          {/* 메인 페이지 (디너 목록) */}
          <Route path="/" element={<DinnerListPage />} />

          {/* 디너 상세 페이지 */}
          <Route path="/dinner/:dinnerId" element={<DinnerDetailPage />} />

          {/* 장바구니 */}
          <Route path="/cart" element={<CartPage />} />

          {/* 로그인 & 회원가입 */}
          <Route path="/login" element={<LoginPage />} />
          <Route path="/register" element={<RegisterPage />} />

          {/* 404 리다이렉트 */}
          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>

        {/* 3. AI 사이드바 (Routes 바깥에 배치하여 오버레이 처리) */}
        <AIChatDrawer />

      </div>
    </BrowserRouter>
  );
};

export default App;