// import React, { useState, useEffect } from 'react';
// import { useNavigate } from 'react-router-dom';
// import apiClient from '../../lib/axios';
// import { DinnerResponseDto } from '../../types/api';
// import { DinnerCard } from './components/DinnerCard';

// export const DinnerListPage: React.FC = () => {
//   const navigate = useNavigate();
//   const [dinners, setDinners] = useState<DinnerResponseDto[]>([]);
//   const [loading, setLoading] = useState(true);
//   const [error, setError] = useState<string | null>(null);

//   useEffect(() => {
//     const fetchDinners = async () => {
//       try {
//         setLoading(true);
//         const response = await apiClient.get('/dinners/getAllDinners');
//         setDinners(response.data.filter((d: DinnerResponseDto) => d.active));
//       } catch (err) {
//         console.error('Failed to fetch dinners', err);
//         setError('디너 목록을 불러오는데 실패했습니다.');
//       } finally {
//         setLoading(false);
//       }
//     };
//     fetchDinners();
//   }, []);

//   if (loading) {
//     return (
//       <div className="flex items-center justify-center min-h-screen">
//         <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-green-600"></div>
//       </div>
//     );
//   }

//   if (error) {
//     return (
//       <div className="flex flex-col items-center justify-center min-h-screen">
//         <p className="text-red-600 text-lg mb-4">{error}</p>
//         <button
//           onClick={() => window.location.reload()}
//           className="text-green-600 hover:underline"
//         >
//           다시 시도
//         </button>
//       </div>
//     );
//   }

//   return (
//     <div className="max-w-6xl mx-auto p-4">
//       {/* 헤더 */}
//       <header className="mb-8">
//         <h1 className="text-3xl font-bold text-gray-900 mb-2">Mr. DAEBAK</h1>
//         <p className="text-gray-600">특별한 디너를 주문하세요</p>
//       </header>

//       {/* 디너 카드 그리드 */}
//       <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
//         {dinners.map((dinner) => (
//           <DinnerCard
//             key={dinner.id}
//             dinner={dinner}
//             onClick={() => navigate(`/dinner/${dinner.id}`)}
//           />
//         ))}
//       </div>

//       {dinners.length === 0 && (
//         <div className="text-center py-12">
//           <p className="text-gray-500 text-lg">등록된 디너가 없습니다.</p>
//         </div>
//       )}
//     </div>
//   );
// };

import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
// import apiClient from '../../lib/axios'; // API 꼴보기 싫어서 주석 처리
import { DinnerResponseDto } from '../../types/api';
import { DinnerCard } from './components/DinnerCard';

// 1. 임시 가짜 데이터 (이걸로 화면을 강제로 띄웁니다)
const MOCK_DINNERS: DinnerResponseDto[] = [
  {
    id: '1',
    dinnerName: 'Valentine Dinner',
    description: '작은 하트 모양과 큐피드가 장식된 접시에 냅킨과 함께 와인과 스테이크가 제공됩니다.',
    basePrice: 55000,
    active: true,
  },
  {
    id: '2',
    dinnerName: 'French Dinner',
    description: '커피 한잔, 와인 한잔, 샐러드, 그리고 최고급 스테이크가 제공됩니다.',
    basePrice: 48000,
    active: true,
  },
  {
    id: '3',
    dinnerName: 'English Dinner',
    description: '에그 스크램블, 베이컨, 빵, 스테이크가 포함된 든든한 영국식 식사입니다.',
    basePrice: 42000,
    active: true,
  },
  {
    id: '4',
    dinnerName: 'Champagne Feast Dinner',
    description: '샴페인 1병, 4개의 바게트빵, 커피 1포트, 와인, 스테이크 (2인용)',
    basePrice: 120000,
    active: true,
  },
];

export const DinnerListPage: React.FC = () => {
  const navigate = useNavigate();

  // 2. 초기값을 가짜 데이터로 바로 설정 (로딩 그딴 거 없음)
  const [dinners] = useState<DinnerResponseDto[]>(MOCK_DINNERS);
  
  // 3. API 호출하던 useEffect 다 지워버림

  return (
    <div className="max-w-6xl mx-auto p-4">
      {/* 헤더 */}
      <header className="mb-8 mt-4 flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Mr. DAEBAK</h1>
          <p className="text-gray-600">특별한 디너를 주문하세요 (UI 테스트 모드)</p>
        </div>
        <button 
          onClick={() => navigate('/login')}
          className="bg-gray-200 px-4 py-2 rounded text-sm hover:bg-gray-300"
        >
          로그인 페이지 가기
        </button>
      </header>

      {/* 디너 카드 그리드 */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 pb-20">
        {dinners.map((dinner) => (
          <DinnerCard
            key={dinner.id}
            dinner={dinner}
            onClick={() => navigate(`/dinner/${dinner.id}`)}
          />
        ))}
      </div>
    </div>
  );
};
