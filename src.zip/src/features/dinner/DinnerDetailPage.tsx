import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import apiClient from '../../lib/axios';
import { useCartStore } from '../../stores/useCartStore'; // Zustand 스토어 import
import { DinnerResponseDto } from '../../types/api';

// [API 부재로 인한 상수 데이터]
// 실제 백엔드 DB의 ID와 일치해야 정확한 주문이 가능합니다.
// 도현(백엔드) 님에게 서빙 스타일 ID를 물어보거나, API를 만들어달라고 하세요.
const SERVING_STYLES = [
  { id: 'style_simple', styleName: 'Simple', extraPrice: 0, description: '플라스틱 용기 제공' },
  { id: 'style_grand', styleName: 'Grand', extraPrice: 5000, description: '도자기 접시, 나무 쟁반' },
  { id: 'style_deluxe', styleName: 'Deluxe', extraPrice: 10000, description: '꽃 장식, 린넨 냅킨, 유리잔' },
];

export const DinnerDetailPage: React.FC = () => {
  const { dinnerId } = useParams<{ dinnerId: string }>();
  const navigate = useNavigate();
  
  // Zustand 스토어에서 장바구니 추가 함수 가져오기
  const addToCartStore = useCartStore((state) => state.addToCart);

  const [dinner, setDinner] = useState<DinnerResponseDto | null>(null);
  const [loading, setLoading] = useState(true);

  // 사용자 선택 상태
  const [selectedStyleId, setSelectedStyleId] = useState<string>('');
  const [quantity, setQuantity] = useState(1);
  const [memo, setMemo] = useState('');

  // 1. 디너 정보 가져오기 (API 연동)
  useEffect(() => {
    const fetchDinner = async () => {
      try {
        setLoading(true);
        // 디너 목록 API 호출 후, ID에 맞는 디너 찾기
        const response = await apiClient.get('/dinners/getAllDinners');
        const foundDinner = response.data.find((d: DinnerResponseDto) => d.id === dinnerId);
        
        if (foundDinner) {
          setDinner(foundDinner);
        } else {
          alert('해당 메뉴를 찾을 수 없습니다.');
          navigate('/');
        }
      } catch (error) {
        console.error('디너 정보 로딩 실패:', error);
        alert('메뉴 정보를 불러오는데 실패했습니다.');
      } finally {
        setLoading(false);
      }
    };

    if (dinnerId) {
      fetchDinner();
    }
  }, [dinnerId, navigate]);

  // 선택된 스타일 정보 찾기
  const selectedStyle = SERVING_STYLES.find((s) => s.id === selectedStyleId);
  const styleExtraPrice = selectedStyle?.extraPrice || 0;

  // 총 가격 계산 (기본가 + 스타일비용) * 수량
  const totalPrice = dinner ? (dinner.basePrice + styleExtraPrice) * quantity : 0;

  // 샴페인 축제 디너 예외 처리 (Simple 선택 불가)
  const isChampagneDinner = dinner?.dinnerName?.toLowerCase().includes('champagne');

  // ★ 핵심: 장바구니 담기 핸들러
  const handleAddToCart = async () => {
    if (!selectedStyleId || !dinner) {
      alert('서빙 스타일을 선택해주세요.');
      return;
    }

    try {
      // 1. [API 호출] 백엔드에 Product 객체 생성 요청
      const productPayload = {
        dinnerId: dinner.id,
        servingStyleId: selectedStyleId, // 백엔드가 인식할 수 있는 ID여야 함
        quantity: quantity,
        memo: memo,
        productName: `${dinner.dinnerName} (${selectedStyle?.styleName})`, 
      };

      // POST /api/products/createProduct
      const response = await apiClient.post('/products/createProduct', productPayload);
      const createdProduct = response.data; // 생성된 Product 객체 (ID 포함)

      // 2. [Zustand 저장] 응답받은 ID와 정보를 프론트엔드 스토어에 저장
      addToCartStore({
        productId: createdProduct.id, // ★ 나중에 결제할 때 사용할 ID
        productName: createdProduct.productName,
        quantity: createdProduct.quantity,
        totalPrice: createdProduct.totalPrice, // 서버가 계산해준 최종 가격
        styleName: createdProduct.servingStyleName
      });

      // 3. 사용자 안내 및 이동
      if (window.confirm('장바구니에 담겼습니다! 장바구니로 이동하시겠습니까?')) {
        navigate('/cart');
      } else {
        navigate('/'); // 쇼핑 계속하기
      }

    } catch (error) {
      console.error('장바구니 담기 실패:', error);
      alert('주문 처리에 실패했습니다. 다시 시도해주세요.');
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-green-600"></div>
      </div>
    );
  }

  if (!dinner) return null;

  return (
    <div className="max-w-2xl mx-auto p-4 pb-32">
      {/* 뒤로가기 버튼 */}
      <button
        onClick={() => navigate(-1)}
        className="mb-4 flex items-center text-gray-600 hover:text-gray-900"
      >
        <svg className="w-5 h-5 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
        </svg>
        뒤로가기
      </button>

      {/* 헤더 이미지 */}
      <div className="h-60 bg-gray-200 rounded-xl mb-6 overflow-hidden flex items-center justify-center">
        {dinner.imageUrl ? (
          <img src={dinner.imageUrl} alt={dinner.dinnerName} className="w-full h-full object-cover" />
        ) : (
          <span className="text-gray-400 text-6xl">🍽️</span>
        )}
      </div>

      {/* 디너 정보 */}
      <h1 className="text-3xl font-bold mb-2">{dinner.dinnerName}</h1>
      <p className="text-gray-600 mb-2">{dinner.description}</p>
      <p className="text-xl font-semibold text-green-600 mb-6">
        기본가 ₩{dinner.basePrice.toLocaleString()}
      </p>

      <hr className="border-gray-200 my-6" />

      {/* 서빙 스타일 선택 섹션 */}
      <h2 className="text-xl font-bold mb-4">서빙 스타일 선택 (필수)</h2>
      <div className="space-y-3">
        {SERVING_STYLES.map((style) => {
          // 샴페인 디너일 경우 Simple 스타일 비활성화
          const isDisabled = isChampagneDinner && style.styleName === 'Simple';

          return (
            <label
              key={style.id}
              className={`flex justify-between items-center p-4 border rounded-lg transition-colors cursor-pointer ${
                isDisabled
                  ? 'bg-gray-100 border-gray-200 opacity-50 cursor-not-allowed'
                  : selectedStyleId === style.id
                  ? 'bg-green-50 border-green-600 ring-1 ring-green-600'
                  : 'bg-white border-gray-200 hover:bg-gray-50'
              }`}
            >
              <div className="flex items-center">
                <input
                  type="radio"
                  name="servingStyle"
                  value={style.id}
                  checked={selectedStyleId === style.id}
                  onChange={(e) => setSelectedStyleId(e.target.value)}
                  disabled={isDisabled}
                  className="w-4 h-4 text-green-600 focus:ring-green-500"
                />
                <div className="ml-3">
                  <span className="block font-medium text-gray-900">
                    {style.styleName}
                    {isDisabled && <span className="text-xs text-red-500 ml-2">(선택 불가)</span>}
                  </span>
                  <span className="block text-sm text-gray-500">{style.description}</span>
                </div>
              </div>
              <span className="text-gray-900 font-medium">
                {style.extraPrice > 0 ? `+ ₩${style.extraPrice.toLocaleString()}` : '무료'}
              </span>
            </label>
          );
        })}
      </div>

      {/* 요청사항 (Memo) */}
      <div className="mt-8">
        <h2 className="text-xl font-bold mb-4">특별 요청사항</h2>
        <textarea
          className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent resize-none"
          rows={3}
          placeholder="예: 샴페인 2병으로 변경해주세요. (추가 비용 발생 가능)"
          value={memo}
          onChange={(e) => setMemo(e.target.value)}
        />
      </div>

      {/* 하단 고정 주문 버튼 */}
      <div className="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 p-4 shadow-[0_-4px_6px_-1px_rgba(0,0,0,0.1)]">
        <div className="max-w-2xl mx-auto flex items-center justify-between">
          {/* 수량 조절 버튼 */}
          <div className="flex items-center space-x-4">
            <button
              onClick={() => setQuantity(Math.max(1, quantity - 1))}
              className="w-10 h-10 rounded-full bg-gray-200 hover:bg-gray-300 text-xl font-bold transition-colors"
            >
              -
            </button>
            <span className="text-lg font-medium w-8 text-center">{quantity}</span>
            <button
              onClick={() => setQuantity(quantity + 1)}
              className="w-10 h-10 rounded-full bg-gray-200 hover:bg-gray-300 text-xl font-bold transition-colors"
            >
              +
            </button>
          </div>

          {/* 카트 담기 버튼 */}
          <button
            onClick={handleAddToCart}
            disabled={!selectedStyleId}
            className={`font-bold py-3 px-8 rounded-lg transition-colors flex-1 ml-6 ${
              selectedStyleId
                ? 'bg-green-600 hover:bg-green-700 text-white'
                : 'bg-gray-300 text-gray-500 cursor-not-allowed'
            }`}
          >
            카트에 담기 • ₩{totalPrice.toLocaleString()}
          </button>
        </div>
      </div>
    </div>
  );
};