// src/types/api.ts
// API 응답 타입 정의 (api-docs.json 기반)

export interface UserResponseDto {
  id: string;
  username: string;
  email: string;
  loyaltyLevel: string; // 단골 고객 할인 관련 (예: 'BRONZE', 'SILVER', 'GOLD')
  createdAt: string;
}

export interface DinnerResponseDto {
  id: string;
  dinnerName: string;
  description: string;
  basePrice: number;
  active: boolean;
  imageUrl?: string;
}

export interface ServingStyleResponseDto {
  id: string;
  styleName: string; // 'Simple', 'Grand', 'Deluxe'
  description: string;
  extraPrice: number;
  active: boolean;
}

export interface DinnerMenuItemResponseDto {
  menuItemId: string;
  menuItemName: string;
  defaultQuantity: number;
}

// PDF 요구사항: 디너 + 스타일 + 수량 + 메모 = Product
export interface CreateProductRequest {
  dinnerId: string;
  servingStyleId: string;
  quantity: number;
  memo: string; // "커피 빼고 빵 추가해주세요" 등의 커스텀 요청
  productName: string;
}

export interface ProductResponseDto {
  id: string;
  productName: string;
  dinnerId: string;
  servingStyleId: string;
  quantity: number;
  memo: string;
  totalPrice: number;
}

// 장바구니 관련 타입
export interface CartItemDto {
  id: string;
  productId: string;
  productName: string;
  quantity: number;
  unitPrice: number;
  totalPrice: number;
}

export interface CartResponseDto {
  id: string;
  userId: string;
  items: CartItemDto[];
  totalAmount: number;
}

// 주문 관련 타입
export interface OrderResponseDto {
  id: string;
  userId: string;
  items: CartItemDto[];
  totalAmount: number;
  discountAmount: number; // 단골 할인 적용 금액
  finalAmount: number;
  status: string;
  createdAt: string;
}

// 로그인/회원가입 관련
export interface LoginRequest {
  username: string;
  password: string;
}

export interface LoginResponse {
  accessToken: string;
  user: UserResponseDto;
}

export interface RegisterRequest {
  username: string;
  email: string;
  password: string;
}
